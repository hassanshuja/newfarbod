class StorageKeys {
    static USER_ID = "userId";
    static EMAIL = "email";
    static PHOTO_URL = "photoURL";

    //static BASE_API_URL = "https://smart-learning-backend.herokuapp.com/" FBA paiini bood
    static BASE_API_URL = "http://localhost:7000/"
}
export default StorageKeys;
