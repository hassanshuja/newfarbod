import React from "react";
import { IndexLink, Link } from "react-router";

class testComp extends React.Component {
  render() {

    return (
      <div>
        <h1> HI sosis </h1>
      </div>
    );
  }
}
export default testComp
